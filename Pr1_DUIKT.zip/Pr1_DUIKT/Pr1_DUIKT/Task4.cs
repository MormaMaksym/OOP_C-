﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr1_DUIKT
{
    internal class Task4
    {
        public void task(int num)
        {
            Random random = new Random();

            int[] X = new int[10 + num];
            List<int> Y = new List<int>();

            Console.Write("M = ");
            int M = int.Parse(Console.ReadLine());

            for (int i = 0; i < X.Length; i++)
            {
                X[i] = random.Next(-100, 101);
                Console.WriteLine($"X[{i}] = {X[i]}");
                if (X[i] >= M)
                {
                    Y.Add(X[i]);
                }
            }

            Console.WriteLine("Y = [");
            foreach (int i in Y)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("]");
        }
    }
}
