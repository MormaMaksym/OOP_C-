﻿using Pr1_DUIKT;

main();

static void main()
{
    Task1 task1 = new Task1();
    Task2 task2 = new Task2();
    Task3 task3 = new Task3();
    Task4 task4 = new Task4();

    Console.Write(
       "1 - task1\n" +
       "2 - task2\n" +
       "3 - task3\n" +
       "4 - task4\n" +
       " >> " 
    );
    int task = int.Parse(Console.ReadLine());

    switch (task)
    {
        case 1:
            task1.task(1);
            break;
        case 2:
            task2.task();
            break;
        case 3:
            task3.task(1);
            break;
        case 4:
            task4.task(1);
            break;
    }
}
