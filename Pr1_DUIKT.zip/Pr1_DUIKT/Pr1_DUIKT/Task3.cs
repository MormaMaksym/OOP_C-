﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr1_DUIKT
{
    internal class Task3
    {
        public void task(int num)
        {
            Random random = new Random();

            int[] X = new int[10 + num];

            for (int i = 0; i < X.Length; i++)
            {
                X[i] = random.Next(1, 101);
                Console.WriteLine($"X[{i}] = {X[i]}");
            }

            Console.WriteLine("\n\nmax = " + X.Max());
            Console.WriteLine("min = " + X.Min());
        }
    }
}
