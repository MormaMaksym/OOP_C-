﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr1_DUIKT
{
    internal class Task2
    {
        public void task()
        {
            Console.Write("side 1 = ");
            int side1 = int.Parse(Console.ReadLine());
            Console.Write("side 2 = ");
            int side2 = int.Parse(Console.ReadLine());
            Console.Write("side 3 = ");
            int side3 = int.Parse(Console.ReadLine());

            int P = side1 + side2 + side3;
            Console.WriteLine($"P = {P}");

            int p = P / 2;
            double S = Math.Sqrt(p * (p - side1) * (p - side2) * (p - side3));
            Console.WriteLine($"S = {Math.Round(S, 2)}");

            Console.Write("Type: ");
            if (side1 == side2 && side1 == side3)
            {
                Console.WriteLine("equilateral");
            }
            else if (side1 == side2 && side1 != side3 || side1 == side3 && side2 != side3 || side2 == side3 && side1 != side2)
            {
                Console.WriteLine("isosceles");
            }
            else
            {
                Console.WriteLine("default");
            }
        }
    }
}
