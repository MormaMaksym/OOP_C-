﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr1_DUIKT
{
    internal class Task1
    {
        public void task(int num)
        {
            int[] array = new int[3];

            for (int i=0; i < array.Length; i++)
            {
                Console.Write($"n{i + 1} = ");
                array[i] = int.Parse(Console.ReadLine());
            }

            foreach (int n in array)
            {
                if (n >= 1 && n <= 10 + num)
                {
                    Console.WriteLine($"{n} in range(1, {10 + num})");
                }
            }
        }
    }
}
